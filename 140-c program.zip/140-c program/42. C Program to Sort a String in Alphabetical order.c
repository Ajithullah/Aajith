#include <stdio.h>
#include <string.h>

void sortString(char *str) {
    int len = strlen(str);
    int i, j;
    char temp;

    // Bubble sort algorithm to sort the string
    for (i = 0; i < len - 1; i++) {
        for (j = 0; j < len - i - 1; j++) {
            if (strcmp(&str[j], &str[j + 1]) > 0) {
                // Swap str[j] and str[j + 1]
                temp = str[j];
                str[j] = str[j + 1];
                str[j + 1] = temp;
            }
        }
    }
}

int main() {
    char inputString[100];

    // Input the string
    printf("Enter a string: ");
    gets(inputString);

    // Sort the string in alphabetical order
    sortString(inputString);

    // Display the sorted string
    printf("Sorted string: %s\n", inputString);

    return 0;
}
