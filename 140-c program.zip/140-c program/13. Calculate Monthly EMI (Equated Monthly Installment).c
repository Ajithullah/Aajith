#include <stdio.h>
#include <math.h>

int main() {
    double principalAmount, annualInterestRate, monthlyInterestRate, emi;
    int loanTenureMonths;

    printf("Enter the principal amount: ");
    scanf("%lf", &principalAmount);


    printf("Enter the annual interest rate (in percentage): ");
    scanf("%lf", &annualInterestRate);

    
    printf("Enter the loan tenure (in years): ");
    scanf("%d", &loanTenureMonths);

 
    monthlyInterestRate = (annualInterestRate / 12.0) / 100.0;

    int numberOfPayments = loanTenureMonths * 12;

    emi = (principalAmount * monthlyInterestRate * pow(1 + monthlyInterestRate, numberOfPayments)) /
          (pow(1 + monthlyInterestRate, numberOfPayments) - 1);

  
    printf("The Equated Monthly Installment (EMI) is: %.2lf\n", emi);

    return 0;
}
