#include <stdio.h>

#define CONVERT_C_TO_F(celsius) ((celsius * 9/5) + 32)
#define VAR_NAME(base, suffix) base##_##suffix

int main() {
    float celsius;
    
    printf("Enter temperature in degrees Celsius: ");
    scanf("%f", &celsius);
    
    float VAR_NAME(temp, celsius) = CONVERT_C_TO_F(celsius);
    
    printf("%.2f degrees Celsius is equal to %.2f degrees Fahrenheit\n", celsius, VAR_NAME(temp, celsius));
    
    return 0;
}
