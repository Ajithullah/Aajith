#include<stdio.h>
main()
{
int v,n,q,r;
printf("enter value\n");
scanf("%d%d",&v,&n);
q=v%n;
r=v/n;
printf("%d\n",q);
printf("%d",r);

}

