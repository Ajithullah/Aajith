#include <stdio.h>

int countDigits(int num) {
    int count = 0;

    // Handle the case of num being 0 separately
    if (num == 0) {
        return 1;
    }

    while (num != 0) {
        num /= 10; // Remove the last digit
        count++;   // Increment the count
    }

    return count;
}

int main() {
    int number;

    // Input the number
    printf("Enter an integer: ");
    scanf("%d", &number);

    // Calculate the number of digits
    int digitCount = countDigits(number);

    // Display the result
    printf("Number of digits in %d: %d\n", number, digitCount);

    return 0;
}
