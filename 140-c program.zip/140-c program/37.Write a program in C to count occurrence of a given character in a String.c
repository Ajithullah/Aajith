#include <stdio.h>
#include <conio.h>
int main()
{
	char str[20], ch;
	int count = 0,i;
	printf("\nenter a string : ");
	scanf("%s", &str);
	printf("\nenter the characted to be sharched : ");
	scanf("%c", &ch);
	for(i = 0;str[i] != '\0'; i++)
	{
		if(str[i] == ch)
		count++;
	}
	if (count == 0)
	printf("\ncharacter '%c' is not prsented", ch);
	else
	printf("\noccurence of character '%c' : %d", ch , count);

}
