#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isPalindrome(char *str) {
    int len = strlen(str);
    int i, j;

    // Initialize indices for the beginning and end of the string
    i = 0;
    j = len - 1;

    while (i < j) {
        // Ignore non-alphanumeric characters from both ends
        while (!isalnum(str[i]) && i < j) {
            i++;
        }
        while (!isalnum(str[j]) && i < j) {
            j--;
        }

        // Compare the characters (case-insensitive)
        if (tolower(str[i]) != tolower(str[j])) {
            return 0; // Not a palindrome
        }

        i++;
        j--;
    }

    return 1; // Palindrome
}

int main() {
    char inputString[100];

    // Input the string
    printf("Enter a string: ");
    gets(inputString);

    // Check if the string is a palindrome
    if (isPalindrome(inputString)) {
        printf("The string is a palindrome.\n");
    } else {
        printf("The string is not a palindrome.\n");
    }

    return 0;
}
