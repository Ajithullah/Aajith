#include <stdio.h>
#include <math.h>

int main() {
    double number, squareRoot, logarithm, exponent;

    
    printf("Enter a number: ");
    scanf("%lf", &number);

 
    squareRoot = sqrt(number);

   
    logarithm = log(number);

   
    exponent = exp(number);

  
    printf("Square root: %.4lf\n", squareRoot);
    printf("Natural logarithm: %.4lf\n", logarithm);
    printf("Exponential value: %.4lf\n", exponent);

    return 0;
}
