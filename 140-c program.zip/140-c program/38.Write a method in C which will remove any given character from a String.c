#include <stdio.h>
#include <string.h>

void removeCharacter(char *str, char chToRemove) {
    int len = strlen(str);
    int i, j = 0;

    for (i = 0; i < len; i++) {
        if (str[i] != chToRemove) {
            str[j++] = str[i];
        }
    }
    str[j] = '\0'; // Null-terminate the modified string
}

int main() {
    char inputString[100];
    char characterToRemove;

    // Input the string
    printf("Enter a string: ");
    gets(inputString);

    // Input the character to remove
    printf("Enter the character to remove: ");
    scanf(" %c", &characterToRemove); // Use a space before %c to skip leading whitespace

    // Remove the specified character from the string
    removeCharacter(inputString, characterToRemove);

    // Display the modified string
    printf("String after removing '%c': %s\n", characterToRemove, inputString);

    return 0;
}
