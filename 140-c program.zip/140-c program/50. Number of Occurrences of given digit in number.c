#include <stdio.h>

int countOccurrences(int number, int digit) {
    int count = 0;

    while (number != 0) {
        int lastDigit = number % 10; // Extract the last digit
        if (lastDigit == digit) {
            count++; // Increment the count if the digit matches
        }
        number /= 10; // Remove the last digit
    }

    return count;
}

int main() {
    int number, digit;

    // Input the number and digit
    printf("Enter an integer: ");
    scanf("%d", &number);
    printf("Enter a digit to count: ");
    scanf("%d", &digit);

    // Calculate the number of occurrences
    int occurrenceCount = countOccurrences(number, digit);

    // Display the result
    printf("Number of occurrences of digit %d in %d: %d\n", digit, number, occurrenceCount);

    return 0;
}
