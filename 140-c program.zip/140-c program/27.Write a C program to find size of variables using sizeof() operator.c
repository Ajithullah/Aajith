#include <stdio.h>

int main() {
    int integerVar;
    float floatVar;
    char charVar;
    double doubleVar;

    // Using sizeof() to find the size of variables
    printf("Size of int: %zu bytes\n", sizeof(integerVar));
    printf("Size of float: %zu bytes\n", sizeof(floatVar));
    printf("Size of char: %zu bytes\n", sizeof(charVar));
    printf("Size of double: %zu bytes\n", sizeof(doubleVar));

    // Using sizeof() to find the size of data types
    printf("Size of int data type: %zu bytes\n", sizeof(int));
    printf("Size of float data type: %zu bytes\n", sizeof(float));
    printf("Size of char data type: %zu bytes\n", sizeof(char));
    printf("Size of double data type: %zu bytes\n", sizeof(double));

    return 0;
}





