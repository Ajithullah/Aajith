#include <stdio.h>
#include <string.h>
#include <ctype.h>

void keepAlphabetsOnly(char *str) {
    int len = strlen(str);
    int i, j = 0;

    for (i = 0; i < len; i++) {
        if (isalpha(str[i])) {
            str[j++] = str[i];
        }
    }
    str[j] = '\0'; // Null-terminate the modified string
}

int main() {
    char inputString[100];

    // Input the string
    printf("Enter a string: ");
    gets(inputString);

    // Keep alphabetic characters only in the string
    keepAlphabetsOnly(inputString);

    // Display the modified string
    printf("String with alphabets only: %s\n", inputString);

    return 0;
}
