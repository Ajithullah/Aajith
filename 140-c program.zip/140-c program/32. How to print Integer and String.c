#include <stdio.h>

int main() {
    int integerVar = 42;
    char stringVar[] = "Hello, World!";

    // Print an integer
    printf("Integer: %d\n", integerVar);

    // Print a string
    printf("String: %s\n", stringVar);

    return 0;
}


