#include <stdio.h>

void copyString(char destination[], const char source[]) {
    int i = 0;

    // Copy characters from source to destination
    while (source[i] != '\0') {
        destination[i] = source[i];
        i++;
    }

    // Null-terminate the destination string
    destination[i] = '\0';
}

int main() {
    char source[] = "Hello, World!";
    char destination[20]; // Make sure the destination array is large enough

    // Copy the string without using strcpy()
    copyString(destination, source);

    // Display the copied string
    printf("Source: %s\n", source);
    printf("Copied: %s\n", destination);

    return 0;
}
