#include <stdio.h>

int stringLength(const char *str) {
    int length = 0;

    // Iterate through the string until the null terminator is reached
    while (str[length] != '\0') {
        length++;
    }

    return length;
}

int main() {
    char inputString[100]; // Adjust the array size as needed

    // Input a string
    printf("Enter a string: ");
    scanf("%s", inputString);

    // Calculate the length of the string without using strlen()
    int length = stringLength(inputString);

    // Display the length of the string
    printf("Length of the string is: %d\n", length);

    return 0;
}
