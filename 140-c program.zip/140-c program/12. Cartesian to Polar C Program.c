#include <stdio.h>
#include <math.h>

int main() {
    double x, y, r, theta;

  
    printf("Enter the x-coordinate: ");
    scanf("%lf", &x);

    printf("Enter the y-coordinate: ");
    scanf("%lf", &y);

   
    r = sqrt(x * x + y * y);
    theta = atan2(y, x);

    printf("Polar coordinates (r, ?): (%lf, %lf radians)\n", r, theta);

    return 0;
}
