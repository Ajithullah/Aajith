#include<stdio.h>
 main()
{
	float  celsius,fahrenheit;
	printf("enter celsius value\n");
	scanf("%f", &celsius);
fahrenheit = (1.8 * celsius) + 32;
	printf("celcius value=%f",fahrenheit);
}
