#include <stdio.h>

void concatStrings(char destination[], const char source[]) {
    int i = 0, j = 0;

    // Find the end of the destination string
    while (destination[i] != '\0') {
        i++;
    }

    // Copy characters from source to destination
    while (source[j] != '\0') {
        destination[i] = source[j];
        i++;
        j++;
    }

    // Null-terminate the destination string
    destination[i] = '\0';
}

int main() {
    char str1[100]; // Adjust the array size as needed
    char str2[100]; // Adjust the array size as needed

    // Input two strings
    printf("Enter the first string: ");
    scanf("%s", str1);

    printf("Enter the second string: ");
    scanf("%s", str2);

    // Concatenate the strings without using strcat()
    concatStrings(str1, str2);

    // Display the concatenated string
    printf("Concatenated String: %s\n", str1);

    return 0;
}


