#include <stdio.h>

int main() {
    int num;

    // Input the integer number
    printf("Enter an integer: ");
    scanf("%d", &num);

    // Multiply the number by 2 without using the multiplication operator
    int result = num + num;

    // Display the result
    printf("Result of multiplying %d by 2 is: %d\n", num, result);

    return 0;
}





