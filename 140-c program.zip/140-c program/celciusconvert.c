#include<stdio.h>
 main()
{
	float  Fahrenheit,Celsius;
	printf("enter fahrenheit value\n");
	scanf("%f",&Fahrenheit);
Celsius = ((Fahrenheit-32)*5)/9;
	printf("celcius value=%f",Celsius);
}
