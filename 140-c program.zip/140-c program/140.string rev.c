#include<stdio.h>
int main()
{
	char std[10];
	printf("enter any character: ");
	gets(std);
	printf("%s", strrev(std));
}
