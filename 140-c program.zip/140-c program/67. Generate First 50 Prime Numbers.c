#include<stdio.h>
#include<conio.h>
int main()
{
    int i, count=0, j,n;
    printf("Prime numbers between 1 to asn num are:\n");
    scanf("%d", &n);
    for(i=1; i<=n; i++)
    {
        for(j=2; j<i; j++)
        {
           if(i%j==0)
           {
               count++;
               break;
           }
        }
        if(count==0 && i!=1)
            printf("%d\n", i);
        count = 0;
    }
    getch();
    return 0;
}
