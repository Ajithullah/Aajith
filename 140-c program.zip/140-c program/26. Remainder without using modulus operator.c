#include <stdio.h>

int main() {
    int dividend, divisor;

    // Input the dividend and divisor
    printf("Enter the dividend: ");
    scanf("%d", &dividend);

    printf("Enter the divisor: ");
    scanf("%d", &divisor);

    // Calculate the remainder without using the modulus operator
    int remainder = dividend;
    while (remainder >= divisor) {
        remainder -= divisor;
    }

    // Display the remainder
    printf("Remainder of %d divided by %d is: %d\n", dividend, divisor, remainder);

    return 0;
}
