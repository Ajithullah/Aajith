#include <stdio.h>

int main() {
    int subject1, subject2, subject3, subject4, subject5;
    float total, percentage;

    // Input marks for each subject
    printf("Enter marks for Subject 1: ");
    scanf("%d", &subject1);

    printf("Enter marks for Subject 2: ");
    scanf("%d", &subject2);

    printf("Enter marks for Subject 3: ");
    scanf("%d", &subject3);

    printf("Enter marks for Subject 4: ");
    scanf("%d", &subject4);

    printf("Enter marks for Subject 5: ");
    scanf("%d", &subject5);

    // Calculate total marks
    total = subject1 + subject2 + subject3 + subject4 + subject5;

    // Calculate percentage
    percentage = (total / 500.0) * 100.0;

    // Display the total marks and percentage
    printf("Total Marks: %.2f\n", total);
    printf("Percentage: %.2f%%\n", percentage);

    return 0;
}

