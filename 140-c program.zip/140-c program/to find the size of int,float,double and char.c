#include <stdio.h>
int main()
{
printf("size of int: %lu bytes\n", sizeof(int));
printf("size of double: %lu bytes\n", sizeof(double));
printf("size of char: %lu bytes\n", sizeof(char));
printf("size of float: %lu bytes\n", sizeof(float));
}

