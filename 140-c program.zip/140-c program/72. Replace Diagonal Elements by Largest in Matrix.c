#include<stdio.h>


int main()
{
 int i,j,n;
 float a[10][10], lg;

 printf("Enter order of matrix:\n");
 scanf("%d", &n);
 
 printf("Enter matrix elements:\n");
 for(i=0;i< n;i++)
 {
  for(j=0;j< n;j++)
  {
   printf("a[%d][%d]=",i,j);
   scanf("%f", &a[i][j]);
  }
 }
 lg = a[0][0];
 for(i=0;i< n;i++)
 {
  for(j=0;j< n;j++)
  {
   if(a[i][j]>lg)
   {
    lg = a[i][j];
   }
  }
 }
 for(i=0;i< n;i++)
 {
  for(j=0;j< n;j++)
  {
   if(i==j)
   {
    a[i][j] = lg;
   }
  }
 }
 printf("Resultant matrix is:\n");
 for(i=0;i< n;i++)
 {
  for(j=0;j< n;j++)
  {
   printf("%0.2f\t", a[i][j]);
  }
  printf("\n");
 }
 
}
