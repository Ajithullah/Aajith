#include <stdio.h>  
char main()  
{  
char a;
scanf("%d", &a); 
   for(;;)  
   {  
    printf("%d", a);  
   }  

}  

