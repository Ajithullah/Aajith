#include <stdio.h>

int main() {
    int n;
    int sum = 0;

    // Input the value of n
    printf("Enter a positive integer n: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Please enter a positive integer.\n");
        return 1; // Exit with an error code
    }

    // Calculate the sum of the first n natural numbers
    sum = n * (n + 1) / 2;

    // Display the sum
    printf("Sum of the first %d natural numbers: %d\n", n, sum);

    return 0;
}
