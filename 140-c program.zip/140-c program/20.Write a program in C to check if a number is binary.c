#include <stdio.h>

// Function to check if a number is binary
int isBinary(int num) {
    while (num != 0) {
        int digit = num % 10; // Get the last digit
        if (digit != 0 && digit != 1) {
            return 0; // Not a binary digit
        }
        num /= 10; // Remove the last digit
    }
    return 1; // All digits are binary
}

int main() {
    int number;
    
    // Input a number
    printf("Enter a number: ");
    scanf("%d", &number);
    
    // Check if the input number is binary
    if (isBinary(number)) {
        printf("%d is a binary number.\n", number);
    } else {
        printf("%d is not a binary number.\n", number);
    }
    
    return 0;
}
