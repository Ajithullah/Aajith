#include<stdio.h>
int main()
{
	float n;
	int round;
	printf("enter a flooting point number\n");
	scanf("%f", &n);
	round=(int)(n<0? n - 0.5:n+0.5);
	printf("rounded interger:%d", round);
	return 0;
}
