#include<stdio.h>
int main()
{
	int a=40,b=60,c=70,d=50,d=80;
	if(a>d)
	{
		printf("enter first largest number: ")
	}
	if(a)
}
