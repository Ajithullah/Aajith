#include<stdio.h>
int main()
{
int n,i;
unsigned long long of=1;
printf("enter any value:");
scanf("%d", &n);
if(n<0){
printf("error!....");
}
else
{
	for(i=1;i<=n;i++){
		of *= i;
	}
	printf("factorial of %d=%11u", n, of);
	}	
}


