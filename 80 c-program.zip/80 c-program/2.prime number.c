#include<stdio.h>

int main()
{
	int n,i,f;
	printf("enter the nalue: \n");
	scanf("%d", &n);
	if(n==2)
	{
		printf("it is prime number");
		
	}
	else if(n%2==0||n==1)
	{
	printf("%d is not prime number",n);
	}
	else{
	f=1;
	for(i=3;i<=sqrt(n);i=i+2)
	if(n%i==0)
	{
	
	f=0;

	
	}
	if(f==1)
	
	
	printf("%d is prime number",n);
	
	else
	
	printf("%d is not prime",n);
	
	return 0;
	
	
	}
}
	
	
	

