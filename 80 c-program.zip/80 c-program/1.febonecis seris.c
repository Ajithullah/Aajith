#include<stdio.h>
int main()
{
	int a,b,c,i;
	printf("enter a and b value: ");
	scanf("%d%d", &a,&b);
	while(i<=10)
	{
		printf("%d\n", a);
		c=a+b;
		a=b;
		b=c;
		i++;
	}
} 

