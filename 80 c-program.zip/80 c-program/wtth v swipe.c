#include<stdio.h>
int main()
{
	int a=5,b=10,temp;
	printf("bs fv=%d\n sv=%d\n", a,b);
	temp=a;
	a=b;
	b=temp;
	printf("as fv=%d\n sv=%d\n", a,b);
}
