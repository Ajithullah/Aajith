#include<stdio.h>
int main()
{
	int year;
	printf("enter a year: ");
	scanf("%d", &year);
	if(year%4==0)
	{
		printf("%d is a leep year", year);
	}
	else
	{
		printf("%d is not leep year", year);
	}
}
