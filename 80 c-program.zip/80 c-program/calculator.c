#include<stdio.h>
int main()
{
	int a,b,c;
	printf("enter your choice: \n");
	printf("1 addtion\n");
	printf("2 subbraction\n");
	printf("3 multiplication\n");
	printf("4 divition\n");
	printf("5 modulus\n");
	printf("enter your choice: \n");
	scanf("%d", &a);
	printf("enter your 1st number");
	scanf("%d", &b);
	printf("enter your second number");
	scanf("%d", &c);
	switch (a)
		{
			case 1:
				printf("%d", b+c);
				break;
				case 2:
					printf("%d", b-c);
					break;
					case 3:
						printf("%d", b*c);
						break;
						case 4:
							printf("%d", b/c);
							break;
							case 5:
								printf("%d", b%c);
								break;
								default:
									printf("error value");
									break;
		}
}
