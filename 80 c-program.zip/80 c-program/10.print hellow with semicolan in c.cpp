#include<stdio.h>  
 int main()    
{    
switch(printf("hello world")){}    
 
}   
