#include<stdio.h>
int main()
{
	int a,b;
	
		printf("enter += value");
		scanf("%d%d", &a,&b);
		printf("%d", a+=b);


	printf("enter -= value");
	scanf("%d%d", &a,&b);
	print("%d", a-=b);


	printf("enter *= value");
	scanf("%d%d", &a,&b);
	printf("%d", a*=b);


	printf("enter /= value");
	scanf("%d%d" &a,&b);
	printf("%d", a/=b);


	printf("enter %= value");
	scanf("%d%d", &a,&b);
	printf("%d", a%=b);

}
