#include<stdio.h>
int main()
{
	float a,b,c;
	printf("enter two number: ");
	scanf("%f%f", &a,&b);
	c=a/b;
	printf("the result is = %f", c);
	
}
