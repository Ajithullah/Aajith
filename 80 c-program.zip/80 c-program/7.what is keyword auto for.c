#include<stdio.h>
int main()
{
	auto int num=2;
	printf("the number is: %d\n", num);
	{
		auto int num=8;
		printf("the number is: %d\n", num);
	}
	printf("the number is: %d\n", num);
}
