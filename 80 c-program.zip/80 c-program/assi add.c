#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value: ");
	scanf("%d%d", &a,&b);
	printf("a+=b %d", a+=b);
}
