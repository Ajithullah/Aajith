<?php
	$conn = new mysqli('localhost', 'root', '', 'market');
	
	if(!$conn){
		die("Error!: Cannot connect to the database!");
	}
?>