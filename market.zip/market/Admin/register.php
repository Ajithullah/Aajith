<?php
include "db.php";
if(isset($_POST['register']))
{
	
$username = $_POST['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$number = $_POST['number'];
$adress = $_POST['adress'];
$age = $_POST['age'];
$name = $_POST['name'];
$savecode="INSERT INTO `emploeey`( `user name`, `password`, `email`, `number`, `adress`,`age`,`name`) VALUES ('$username','$password','$email','$number','$adress','$age','$name')";
$run_query=mysqli_query($conn,$savecode);
if($run_query)
{
	echo "alert('data is sucessfully register')";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript"> 
function onsubmit_validation()
{
 if(document.hi.username.value=="")
    {
        alert ("Please fill ur user name.");
        document.hi.username.focus();
        return false;
    }
	if(document.hi.name.value=="")
    {
        alert ("Please fill ur name.");
        document.hi.name.focus();
        return false;
    }
 if(document.hi.password.value=="")
	{
	  alert ("enter your password");
	  document.hi.password.focus();
	  return false
	  }
	if(document.hi.email.value=="")
{
alert ("enter your email");
document.hi.email.focus();
return false;	
}
 if(document.hi.number.value=="")
 {
 alert("enter your number");
 document.hi.number.focus();
 return false;
 }
 if(document.hi.adress.value=="")
 {
 alert("enter your address");
 document.hi.adress.focus();
 return false;
 }
 if(document.hi.age.value=="")
 {
 alert("enter your age");
 document.hi.age.focus();
 return false;
 }
 
}
</script>
<title>REGISTER FORM</title>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<style>
	h1{
		text-align:center;
	}
	nav{
		background-color:blue;
	}
	.reg{
		margin-left:500px;
		margin-top:200px;
	}
	footer{
	
		margin-top:220px;
	}
	table{
		background-color:pink;
	}
	body{
		background-color:#a9a9a9;
	}
</style>
<body class="container-fluid" >
<nav class="nav nav-tabs">
	
<h1>EMPLOEEY REGISTER FORM  <button class="btn btn-danger"><a href="../admin ind.php" style="text-decoration: none;color: #428bca;"> Home</a></button></h1>

</nav>

<form method="POST" name="hi" style="width:50%;margin-left:300px;">
<div class="form-group">

<label ><h3>User Name:</h3></label>
<input type="text" name="username" class="form-control" require>

<label><h3>Name:</h3></label>
<input type="text" name="name" class="form-control" require>

<label><h3>Password:</h3></label>
<input type="password" name="password" class="form-control" require>

<label><h3>Email:</h3></label>
<input type="email" name="email" class="form-control" require>

<label><h3>Mobile Number:</h3></label>
<input type="text" name="number" class="form-control" require>

<label><h3>Adress:</h3></label>
<input type="text" name="adress" class="form-control" require>

<label><h3>Age:</h3></label>
<input type="number" name="age" class="form-control" require>
<br><br>
<button type="submit" style="width:15%" value="regester" class="btn btn-primary" onclick="onsubmit_validation()" name="register"><h4>Register</h4></button>
<button type="reset"  class="btn btn-primary" style="width:15%"><h4>Reset</h4></button>

</table>
</form>

</div>
<footer class="bg-body-tertiary text-center text-lg-start" style="height:150px">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: #404040;">
   <p style="color:#FFD700"> © 2016 Copyright:Register Page</p>
    <a class="text-body" href="https://mdbootstrap.com/"></a>
  </div>
</body>
</html>