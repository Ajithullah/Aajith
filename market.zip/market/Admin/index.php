<?php require ('../db/config.php'); ?>
<?php require ('db/session.php'); ?>
<?php if (!isset($no_visible_elements) || !$no_visible_elements) { ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Markat.Com-Index</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../bootstrap/style.css">
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <script src="../bootstrap/js/jquery.min.js"></script>
  <script src="../bootstrap/js/bootstrap.min.js"></script>
  <style>
  body {
  
      color: #777;
    
      background-color:#d2d2d2;
  }
  h4 {
      margin: 10px 0 30px 0;
      letter-spacing: 10px;      
      font-size: 20px;
      color: #111;
  }
  .nav-tabs li a {
      color: #777;
  }
  li{
    margin-top:-30px;
  }
  .navbar {
      font-family:comic sans Ms,serif;
      height: 90px;
      margin-bottom: 0;
      background-color: #2d2d30;
      border: 0;
      font-size: 14px !important;
      letter-spacing: 3px;
      opacity: 0.9;
  }
  .navbar li a, .navbar .navbar-brand { 
    margin-top: 27px;
      color: #d5d5d5 !important;
  }
  .navbar-nav li a:hover {
      color: #fff !important;
  }
  .navbar-nav li.active a {
      color: #fff !important;
      background-color: #29292c !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
  }
  .open .dropdown-toggle {
      color: #fff;
      background-color: #555 !important;
  }
  .dropdown-menu li a {
      color: #000 !important;
  }
  .dropdown-menu li a:hover {
      background-color: #000 !important;
  }
  footer {
      background-color: #2d2d30;
      color: #f5f5f5;
      padding: 32px;
   width:1322px;
   
  }
  footer a {
      color: #f5f5f5;
    
  }
  footer a:hover {
      color: #777;
      text-decoration: none;
  }  
  .form-control {
      border-radius: 0;
  }
  textarea {
      resize: none;
  }
#to:hover{
  border-radius:150px;
}
  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-default navbar-fixed-top" style="height:60px">
  <div class="container-fluid" >
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" style="margin-top:10px" href="#myPage">Markat.com</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right" style="margin-right:80px;">
        <li><a href="#myPage"><button style="width:110px;height:30px;" class="btn btn-primary">Admin Page</button></a></li>
        <?php
  $user_query=mysqli_query($conn,"select *  from admin where id='$id_session'")or die(mysqli_error());
  $row=mysqli_fetch_array($user_query); {
?>
<li><a role="menuitem" href="logout.php" class="glyphicon glyphicon-log-out" style="color: red;"><button class="btn btn-danger">LogOut</button></a></li>
<?php } ?>
<?php } ?>
      </ul>

    </div>
  </div>
</nav>
<br><br><br>
<div style="background: #000;max-width: 100%;"><p style="margin-left: 100px;font-weight: bolder;"><button class="btn btn-danger" style="height:30px; margin-left:-30px;">Admin</button><a href="" style="text-decoration: none;color: #428bca"><button class="btn btn-primary" style="margin-left:10px;" ><a href="../admin ind.php" style="text-decoration:none;color:black"> Home</a></button></a></p></div>
 <div class="container-fluid" style="max-width: 95%;">
  <div class="row">
  
  
    <div class="col-sm-9" style="background-color:#123000;margin-left:200px;height:360px;margin-top:-10px">
      <h1 style="text-align:center">Admin Page</h1>
      <div class="container" style="max-width: 100%;" >
        <div class="row">
          <div class="col-sm-2">
            <div style="background: #fff666; width: 150px;text-align: center;text-decoration: none;margin-left:150px" id="to">
      <a  href="user.php">
            <i style="font-size: 30px;" class="glyphicon glyphicon-user "></i>
              <?php
              $result = mysqli_query($conn,"SELECT * FROM `member`");
              $num_rows = mysqli_num_rows($result);
              ?>
            <div>Total Users</div>
            <div>1</div>
        </a>
      </div>

      <div class="col-sm-2" id="to">
            <div style="background: #fff666; width: 150px;text-align: center;text-decoration: none;margin-left:370px; margin-top:-75px" id="to">
      <a  href="mensproduct.php">
            <i style="font-size: 30px;" class="glyphicon glyphicon-user"></i>
              <?php
              $result = mysqli_query($conn,"SELECT * FROM member");
              $num_rows = mysqli_num_rows($result);
              ?>
            <div>Emploeey</div>
            <div>2</div>
        </a>
      </div><br>
      <div class="col-sm-2" id="to">
            <div style="background: #fff666; width: 150px;text-align: center;text-decoration: none;margin-left:600px; margin-top:-100px;position:ablout;" id="to">
      <a  href="register.php">
            <i style="font-size: 30px;" class="glyphicon glyphicon-user"></i>
              <?php
              $result = mysqli_query($conn,"SELECT * FROM member");
              $num_rows = mysqli_num_rows($result);
              ?>
            <div>register</div>
            <div>3</div>
        </a>
      </div><br>
     
     
    
          </div>
        </div>
      </div>
      
       
    </div>
  </div>
</div>
 
<!-- Footer -->
<footer class="text-center" style="margin-top:350px">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p >

 © 2016 AllRight Reserved Market.com
</p> 
</footer>

<script>
$(document).ready(function(){
  // Initialize Tooltip
  $('[data-toggle="tooltip"]').tooltip(); 
  
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {

    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {

      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  });

</script>

</body>
</html>
