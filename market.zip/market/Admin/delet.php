<?php
include "db.php";
if(isset($_POST['delet']));
{
	$id=$_GET['delet'];
	$sql="DELETE FROM emploeey where id='$id'";
	$result=mysqli_query($conn,$sql);
	if($result)
	{
		header("location:index.php");
	}
	else
	{
		die(mysqli_error($conn));
	}
}
?>