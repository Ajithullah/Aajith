<!DOCTYPE html>
<html >
<head>
<title>Emploeey </title>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<style>
nav{
	background-color:#d4d4d4;
	position:relative;
}
.num{
	margin-top:-45px;
	margin-left:1100px;
	
}
footer{
	margin-top:100px;
}
body{
	background-color:#f6f6;
}
table{
	background-color:pink;
}
h2{
	text-align:center;
}
</style>
<body class="container-fluid">

<nav class="nav">
<h2 class="nave-item">Emploeey page</h2></li>
  <a class="nav-link active" href="../admin ind.php" style="float:right;padding-left:10px;"><button class="btn btn-danger">Home</button></a>
  <a class="nav-link" href="register.php" style="float:right"><button class="btn btn-primary">Register</button></a>
</nav>
<br><br><br><br><br>
<table border="3" align="center" class="table ">
	<thead>
		<tr>
		<th scope="col">id</th>
	<th scope="col">username</th>
	<th scope="col">password</th>
	<th scope="col">email</th>
	<th scope="col">number</th>
	<th scope="col">adress</th>
	<th scope="col">age</th>
	<th scope="col">name</th>
	<th scope="col">Update</th>
	<th scope="col">Delet</th>
</tr>
</thead>
<tbody>
	<?php
	include "db.php";
	$sel="SELECT * FROM emploeey";
	$result=mysqli_query($conn,$sel);
	if($result)
	{
		
   while($row=mysqli_fetch_assoc($result))
   {
	$id=$row['id'];
	$username=$row['user name'];
	$password=$row['password'];
	$email=$row['email'];
	$number=$row['number'];
	$adress=$row['adress'];
	$age=$row['age'];
	$name=$row['name'];
	
	echo'<tr scope="row">
	<th scope="row"> '.$id.' </th>
	<td> '.$username.' </td>
	<td> '.$password.' </td>
	<td> '.$email.' </td>
	<td> '.$number.' </td>
	<td> '.$adress.' </td>
	<td> '.$age.' </td>
	<td> '.$name.' </td>

	<td><button class="btn btn-into"><a href="update.php? upid='.$id.'" style="text-decoration:none";>update</a></button></td>
	<td><button class="btn btn-danger"><a href="delet.php? delet=' .$id. '" style="text-decoration:none";>delete</a></button></td>
</tr>';
   }
	}
	?>
	</tbody>
</table>
<footer class="bg-body-tertiary text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2016 Copyright:Emploeey List
    <a class="text-body" href="https://mdbootstrap.com/"></a>
  </div>
  <!-- Copyright -->
</footer>
</body>
</html>