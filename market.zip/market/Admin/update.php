<?php
include 'db.php';
$id=$_GET['upid'];

$qry="SELECT * FROM emploeey where id='$id'";
$result=mysqli_query($conn,$qry);
if($row=mysqli_fetch_assoc($result)){
$username=$row['user name'];
$password=$row['password'];
$email=$row['email'];
$number=$row['number'];
$adress=$row['adress'];
$age=$row['age'];
$name=$row['name'];

if(isset($_POST['update']))
{
$username=$_POST['username'];
$password=$_POST['password'];
$email=$_POST['email'];
$number=$_POST['number'];
$adress=$_POST['adress'];
$age=$_POST['age'];
$name=$_POST['name'];	

$query="UPDATE emploeey set id='$id',`user name`='$username',`password`='$password',`email`='$email',`number`='$number',`adress`='$adress',`age`='$age' where id='$id'";

$result=mysqli_query($conn,$query);
if($result)
{
	echo"updated successfully";
	header('location:index.php');
}
else
{
	die(mysqli_error($conn));
}
}
}
?>
<html>
<head>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>
<style>
body{
	background-color:#c0c0c0;
}
	h1{
		text-align:center;
	}
	nav{
		background-color:pink;
	}
	.up{
		text-align:center;
		margin-left:500px;
		margin-top:250px;
		
	}
	table{
		background-color:black;
		margin-left:-200px;
		
	}
	footer{
		text-align:center;
		background-color:gray;
		margin-top:170px;
	}
</style>
<body class="container-fluid" >
<nav>
<div class="nav nav-tabs">
<h1 style="margin-left:400px;">UPDATE PAGE <button class="btn btn-primary" style="margin-left:500px;"><a href="../admin ind.php" style="text-decoration: none;color: white;"> Home</a></button></h1>
</div>
</nav>
<div class="up">
<form name="update" method="POST">
<table border="5" class="table table-into" style="margin-top:-150px;">
<tr>
<td class="scopy-row" style="color:#FFD700;width:50%">username</td>
<td><input type="text" name="username" value=<?php echo $username;?>></td>
</tr>
<tr>
<td class="scopy-row" style="color:#FFD700">password</td>
<td><input type="text" name="password" value=<?php echo $password;?>></td>
</tr>
<tr>
<td class="scopy-row" style="color:#FFD700">name</td>
<td><input type="text" name="name" value=<?php echo $name;?>></td>
</tr>
<tr>
<td class="scopy-row" style="color:#FFD700">email</td>
<td><input type="text" name="email" value=<?php echo $email;?>></td>
</tr>
<tr>
<td class="scopy-row" style="color:#FFD700">number</td>
<td><input type="text" name="number" value=<?php echo $number;?>></td>
</tr>
<tr>
<td class="scopy-row" style="color:#FFD700">adress</td>
<td><input type="text" name="adress" value=<?php echo $adress;?>></td>
</tr>
<tr>
<td class="scopy-row" style="color:#FFD700">age</td>
<td><input type="text" name="age" value=<?php echo $age;?>></td>
</tr>
<tr>
<td ><input type="submit" style="float:right;" class="btn btn-primary" name="update"></td>
<td><button type="reset"  class="btn btn-danger" >Reset</button>
</td>
</tr>
</table>
</form>
</div>
<footer class="bg-body-tertiary text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2016 Copyright:Emploeey Update List
    <a class="text-body" href="https://mdbootstrap.com/"></a>
  </div>
  <!-- Copyright -->
</footer>
</body>
</html>