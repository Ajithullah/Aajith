<?php
$con=mysqli_connect('localhost','root','','mkshope');
if (isset($_POST['payment']) && $_POST['amt'] >=99) {
    $name=$_POST['name'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $amount=$_POST['amt'];
    $pay_to='MCA Foundation (Save Tree , Save India)';
    include 'instamojo\Instamojo.php';
    $api = new Instamojo\Instamojo('test_df9141987c29b303da42690ad49', 'test_a8ee201db389b6e4b31c13586e8', 'https://test.instamojo.com/api/1.1/');
    try {
        $response = $api->paymentRequestCreate(array(
            "purpose" => $pay_to,
            "user_name" => $name,
            "email" => $email,
            "phone" => $phone,
            "amount" => $amount,
            "send_email" => true,
            "allow_repeated_payments" => false,
            "redirect_url" => "http://localhost/Payment/thankyou.php"
            ));
       // print_r($response);
        $url=$response['longurl'];
        header("location:$url");
        }
        catch (Exception $e) {
            print('Error: ' . $e->getMessage());
        }
        $query="INSERT INTO transaction (name,email,phone,amount,pay_to) VALUES ('$name','$email','$phone','$amount','$pay_to')";
        $run=mysqli_query($con,$query);
    }
?>