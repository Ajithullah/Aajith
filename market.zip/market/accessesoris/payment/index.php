<?php
$conn = mysqli_connect('localhost','root','','mkshope');

if(!$conn){
	echo "Connection Failed: ". mysqli_error($conn);
}
?>
<?php 
session_start();
if (!isset($_SESSION['id'])){
header('location:index.php');
}
$id_session=$_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>Payment</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		
		<script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.min.js"></script>
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.css">
		<style>
			label{
				font-weight: bold;
			}
			body{
				background-color:#5DADE2; 
			}
			#to:hover{
				border-radius:50px;
			}
		</style>
	</head>
	<body >

		<div class="container">
			<div class="row">
				<div class="col-md-12 p-5 display-4 text-capitalize text-center">
						<?php
              $result= mysqli_query($conn,"select *  from member where mem_id='$id_session'") or die (mysqli_error());
              while ($row= mysqli_fetch_array ($result) ){
              $id=$row['mem_id'];
              ?>
					<h1 class="text-black">Welcome To <?php echo $row['username']; ?> Fill Your Payment <button class="btn btn-danger" id="to"><a style="text-decoration:none" href="../../index2.php">HOME</a></button></h1>	
					<?php
			  }
			  ?>
				</div>
			</div>

			<div class="row justify-content-center mt-4">
				<div class="col-md-5">
					<div class="card border-0">
						<div class="card-header bg-yellow">
							<h4 class="card-title" style="text-align:center; color:#EC7063;">
								Payment Checkout
							</h4>
						</div>
						<div class="card-body">
						<?php
              $result= mysqli_query($conn,"select *  from member where mem_id='$id_session'") or die (mysqli_error());
              while ($row= mysqli_fetch_array ($result) ){
              $id=$row['mem_id'];
              ?>
							<form action="pay.php" method="post">
								<label for="">Name:</label>
								<div class="form-group">
									<input type="text" name="name" id="name" class="form-control" value=<?php echo $row ['username']; ?> readonly>
								</div>
								<label for="">Email:</label>
								<div class="form-group">
									<input type="email" name="email" id="email" class="form-control" value=<?php echo $row ['email']; ?> readonly>
								</div>
								<label for="">Phone No:</label>
								<div class="form-group">
									<input type="text" name="phone" id="phone" class="form-control" value=<?php echo $row ['profile']; ?> readonly>
								</div>
								<label for="" >Amount:</label>
								<?php
			  }
			  ?>
								<?php
$total_price = 0.00;
if(isset($_SESSION["cart_item"])){
?>	
<?php foreach ($_SESSION["cart_item"] as $item) { 
		// $product_info = $db_handle->runQuery("SELECT * FROM accessesoris WHERE code = '" . $item["code"] . "'");
		$total_price += $item["price"] * $item["quantity"];	
?>

								<div class="form-group">
									<input type="text"  name="amount"  class="form-control" value=<?php  echo ($total_price) ?> readonly>
								</div>
								<?php
}
}
?>
								<div class="form-group">
									<button type="submit" id="to" name="payment" style="width:200px; " class="btn btn-primary" onclick="validate()">Proccess</button>
									<button type="reset" id="to" name="reset" style="width:200px; " class="btn btn-danger" >reset</button>
								</div>
							</form>

						</div>
						
					</div>
				</div>
			</div>
		</div>
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	</body>
</html>