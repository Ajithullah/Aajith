

<html>

<head>
<title>process</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		
		<script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.min.js"></script>
      <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/0.4.2/sweet-alert.css">
</head>
<style>
.container{
	margin-top:150px;
}
h1{
	text-align:center;
}
</style>
<body>
<div class="container">
<div class="card">
<div class="card-body">
<div class="card-title"><h1>process</h1></div><hr></hr>
<div class="card-form">
<label>cash on delivery :</label>
<input type="radio" ></input><hr></hr>

<label>Pay your amount:<?php echo $item["price"].  number_format($total_price,2). "Rs "; ?></label>
<br><br>
<a href="#"><button class="btn btn-info">order Now</button>
</div>
</div>
</div>
</body>
</html>
