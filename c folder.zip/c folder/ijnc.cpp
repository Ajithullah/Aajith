#include<iostream>
using namespace std;
class aajith
{
	private:int x,y,z;
	public:
		void add()
		{
			cout<<"enter 2 numbers";
			cin>>x>>y;
			z=x+y;
			cout<<"two number"<<z<<endl;
		}
};
int main()
{
	aajith a;
	a.add();
}
