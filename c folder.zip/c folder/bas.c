#include <stdio.h>
int main()
{
	int a=60,b=89;
	(a>b) ? printf("a is small"):printf("b is big");
}
