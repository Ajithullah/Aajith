#include<stdio.h>
int main()
{
	FILE *fp;
	fp=fopen("hi.txt", "a");
	fprintf(fp, "hellow hi");
	fclose(fp);
}
