#include<stdio.h>
int main()
{
	int a,b,c;
	printf("enter your choice");
	printf("choice 1 addition\n");
	printf("choice 2 subraction\n");
	printf("choice 3 multiplication\n");
	printf("choice 4 divition\n");
	printf("choice 5 modulus\n");
	printf("please enter your choice\n");
	scanf("%d",&a);
	printf("enter your first number\n");
	scanf("%d",&b);
	printf("enter second number\n");
	scanf("%d",&c);
	
	switch(a){
	case 1:
		printf("%d", b+c);
	break;
	case 2:
	printf("%d", b-c);
	break;
	case 3:
	printf("%d", b*c);
	break;
	case 4:
	printf("%d", b/c);
	break;
	case 5:
	printf("%d", b%c);
	break;		
    }
}
