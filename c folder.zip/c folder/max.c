#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value");
	scanf("%d%d", &a,&b);
	{
			if(a=b)
			{
			if(a<b)
			{
			printf("a grater then b");
			}
			printf("a less then b");
			}
			printf("a not equal to b");
			}
			}
