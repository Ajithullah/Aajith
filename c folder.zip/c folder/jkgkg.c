#include<iostream>
using namespace std;
int main()
{
	int a=100,b=200;
	cout<< (a,b) ? cout<<"a is big":cout<<"b is small";
}
