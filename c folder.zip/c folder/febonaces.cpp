#include<iostream>
using namespace std;
int main()
{
	int to;
	cout<<"enter any value";
	cin>>to;
	if(to%2==0)
	{
		cout<<"even "<<to;
	}
	else
	{
		cout<<"odd "<<to;
	}
}
