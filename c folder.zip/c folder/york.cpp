#include<iostream>
using namespace std;
class of
{
	public:
		void tiss()
		{
			cout<<"aajith";
		}
};
class on:public of
{
	public:
		void its()
		{
			cout<<endl<<"aajithullah";
		}
};
class one
{
	public:
		void took()
		{
			cout<<endl<<"hi";
		}
};
class two:public on,public one
{
	public:
		void cloud()
		{
			cout<<endl<<"hellow";
		}
};
int main()
{
	two h;
	h.its();
	h.took();
	h.tiss();
	h.cloud();
}
