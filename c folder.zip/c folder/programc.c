#include <stdio.h>
int main()
{
	char x;
	printf ("enter any character");
	scanf ("%c", &x);
	printf ("%c", x);
}
