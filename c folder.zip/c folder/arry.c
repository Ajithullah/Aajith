#include<stdio.h>
int main()
{
	char ch[10]={'h','e','l','l','o'};
	{
		printf("%d", strlen(ch));
	}
}
