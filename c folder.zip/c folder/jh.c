#include<stdio.h>
int main()
{
	int  i,j,k;
	int test[i][j][k];
	printf("enter 12 value");
	for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		{
			for(k=0;k<2;k++)
			{
				scanf("%d", &test[i][j][k]);
			}
		}
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		{
			for(k=0;k<2;k++)
			{
				printf("test[%d][%d][%d]=%d\n", i,j,k, test[i][j][k]);
			}
		}
	}
}
