#include <stdio.h>
int main()
{
	int x=67,y=75;
	printf ("%d", x*y);
}
