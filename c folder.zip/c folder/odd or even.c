#include<stdio.h>
void main()
{
	int aajith;
	printf("enter any nalue:");
	scanf("%d", &aajith);
	if(aajith%2==0)
	{
		printf("%d is even", aajith);
	}
	else
	{
		printf("%d is odd", aajith);
	}
}
