#include<iostream>
using namespace std;
void add();
void sub();
int main()
{
	add();
	sub();
}
void add()
{
	int a=90,b=98;
	cout<<"a+b";
}
void sub()
{
	int a=79,b=97;
	cout<<"a-b";
}
