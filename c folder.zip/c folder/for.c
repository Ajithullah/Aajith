#include<stdio.h>
int main()
{
	int n,i;
	printf("enter starting value");
	scanf("%d", &i);
	printf("enter any value");
	scanf("%d", &n);
	do{
		printf("%d\n", i);
		++i;
	}
	while(i<=n);
}
