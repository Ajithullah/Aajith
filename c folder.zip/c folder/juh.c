#include<stdio.h>
int main()
{
	int i,j,k;
	int aajithullah[i][j][k];
	printf("enter 12 values");
	for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		{
			for(k=0;k<2;k++)
			{
				scanf("%d", &aajithullah[i][j][k]);
			}
		}
	}
	for(i=0;i<2;i++)
	{
		for(j=0;j<3;j++)
		{
			for(k=0;k<2;k++)
			{
				printf("aajithullah[%d][%d][%d]=%d\n", i,j,k,aajithullah[i][j][k]);
			}
		}
	}
}
