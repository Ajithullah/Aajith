#include <stdio.h>
#include <math.h>

int main() {
    float principal, rate, time, emi, interest;
    
    
    printf("Enter the principal amount: ");
    scanf("%f", &principal);
    
    
    printf("Enter the annual interest rate (in percentage): ");
    scanf("%f", &rate);
    
    
    printf("Enter the loan tenure (in years): ");
    scanf("%f", &time);
    
    
    rate = rate / 1200.0; 
    

    emi = (principal * rate * pow(1 + rate, time)) / (pow(1 + rate, time) - 1);
    
    
    interest = (emi * time) - principal;
    
   
    printf("EMI: %.2f\n", emi);
    printf("Total Interest Paid: %.2f\n", interest);
    
    return 0;
}
