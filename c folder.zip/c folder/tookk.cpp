#include<iostream>
using namespace std;
class add
{
	public:
		add()
		{
			cout<<"default constrctor"<<endl;
		}
};
int main()
{
	add b();
}
