#include<stdio.h>
int main()
{
	FILE *fp;
	fp=fopen("aajith.text", "a");
	fprintf(fp, "\n hellow aajithh");
	fclose(fp);
}
