#include <stdio.h>

int main() 
{
    int n = 5; // Change this value to generate a different number of lines

    int num = 0;
    for (int i = 1; i <= n; i++)
	 {
        num = num * 10 + i;
        printf("%d\n", num);
    }

    return 0;
}
