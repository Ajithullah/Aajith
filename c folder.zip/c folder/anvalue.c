#include<stdio.h>
char main()
{
	char a[10],b[8];
	printf("enter a value");
	gets(a);
	printf("enter b value");
	gets(b);
	if(strcmp (a,b)==0)
	{
		printf("string are equal");
	}
	else
	{
		printf("string nor equal");
	}
}
