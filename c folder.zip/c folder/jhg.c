#include<stdio.h>
#include<string.h>
char main()
{
	char a[10],b[20];
	printf("enter\n");
	scanf("%s", &a);
	printf("enter\n");
	scanf("%s", &b);
	strcat(a,b);
	printf("%s", a);
}
