#include<iostream>
using namespace std;
int main()
{
	char i,j;
	for(i=1;i<=5;i++)
	{
		for(j='a';j<=i;j++)
		{
			cout<<j;
		}
		cout<<"\n";
	}
}
