#include<iostream>
using namespace std;
int main()
{
	int at;
	cout<<"enter any value:";
	cin>>at;
	if(at%2==0)
	{
		cout<<"even "<<at;
	}
	else
	{
		cout<<"odd "<<at;
	}
}
