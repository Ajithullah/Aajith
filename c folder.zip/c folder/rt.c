#include<stdio.h>
int main()
{
	int i,j,k,c,g,h;
	printf("enter c,g&h values");
	scanf("%d%d%d", &c,&g,&h);
	int a[c][g][h];
	printf("enter 8 values");
	for(i=0;i<c;i++)
	{
		for(j=0;j<g;j++)
		{
			for(k=0;k<h;k++)
			{
				scanf("%d", &a[i][j][k]);
			}
		}
	}
	for(i=0;i<c;i++)
	{
		for(j=0;j<g;j++)
		{
			for(k=0;k<h;k++)
			{
				printf("a[%d][%d][%d]=%d\n", i,j,k, a[i][j][k]);
			}
		}
	}
}
