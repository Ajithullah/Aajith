#include<iostream>
using namespace std;
void add();
void sub();
void main()
{
	add();
	sub();
	}
	void add()
	{
		int a,b,c;
		cout<<"enter a,b&c value";
		cin>>a>>b>>c;
		cout<<a+b;
	}
	void sub()
	{
		int a,b,c;
		cout<<"enter a,b&c value";
		cin>>a>>b>>c;
		cout<<a-b;
	}
