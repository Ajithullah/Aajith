#include<iostream>
using namespace std;
class it
{
	public:
		void cat()
		{
			cout<<"ant";
		}
};
class of
{
	public:
		void was()
		{
			cout<<endl<<"uno";
		}
};
class tooo:public of,public it
{
	public:
		void you()
		{
			cout<<endl<<"give";
		}
};
int main()
{
	tooo d;
	d.cat();
	d.was();
	d.you();
}
