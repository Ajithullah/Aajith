#include<stdio.h>
int main()
{
	char str[10];
	printf("enter a string");
	gets(str);
	printf("%s", strrev(str));
}
