#include<iostream>
using namespace std;
class aajith
{
	public:
		int num1;
		int nmu2;
		void display()
		{
			num1=20;
		}
		void display2()
		{
		num2=50;
		}
		int getvalue()
		{
			return num1;
		}
		int getvalue2()
		{
			return num2;
		}
};
int main()
{
	aajith a;
	a.display();
	cout<<a.getvalue()<<endl;
	a.display2();
	cout<<a.getvalue2();
	}
