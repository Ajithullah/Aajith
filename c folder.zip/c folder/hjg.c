#include<stdio.h>
int add();
int add1 ();
int main()
{
	add ();
	add1 ();
}
int add ()
{
	int a,b;
	printf("enter a&b value");
	scanf("%d%d", &a,&b);
	printf("%d\n", a+b);
	return a+b;
}
int add1 ()
{
	int a,b,c;
	printf("enter a,b&c value");
	scanf("%d%d%d", &a,&b,&c);
	printf("%d\n", a+b-c);
	return a+b-c;
}
