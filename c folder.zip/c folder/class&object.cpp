#include<iostream>
using namespace std;
class aajith
{
	public:
		void hi()
		{
			cout<<"hi aajithullah";
		}
};
class aajithullah:public aajith
{
public:
	void is()
	{
		cout<<endl<<"hii aajithullah";
	}
};
int main()
{
	aajithullah a;
	a.hi();
	aajith b;
	b.is();
}
