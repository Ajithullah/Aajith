#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value");
	scanf("%d%d", &a,&b);
	++a,++b;
	printf("%d\n%d ", a,b);
}
