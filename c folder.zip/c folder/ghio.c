#include<stdio.h>
int main()
{
	int t=13;
	printf("%d", ++t);
}
