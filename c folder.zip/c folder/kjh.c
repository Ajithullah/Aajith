#include<stdio.h>
void add();
void sub();
void multyplay();
int main()
{
	add();
	sub();
	multyplay();
}
void add()
{
	int a,b;
	printf("enter a&b value");
	scanf("%d%d", &a,&b);
	printf("%d", a+b);
}
void sub()
{
	int a,b;
	printf("enter a&b value");
	scanf("%d%d", &a,&b);
	printf("%d", a-b);
}
void multyplay()
{
	int a,b,c;
	printf("enter a,b&c value");
	scanf("%d%d%d", &a,&b,&c);
	printf("%d", a*b*c);
}
