#include<stdio.h>
void print();
void main()
{
	print();
}
void print()
{
	printf("helloe");
	print();
}
