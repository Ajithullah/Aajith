#include<iostream>
using namespace std;
int main()
{
	int a;
	a=6;
	while(a<15)
	{
		cout<<a;
		a++;
	}
}
