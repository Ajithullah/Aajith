#include<stdio.h>
#include<string.h>
char main()
{
	char str[10];
	printf("enter string value");
	gets(str);
	printf("%s", strrev(str));
}
