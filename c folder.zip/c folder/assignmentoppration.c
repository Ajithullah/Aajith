#include <stdio.h>
int main()
{
	int x=98,y=123;
	printf ("%d", x<y);
}
