#include<stdio.h>
int main()
{
	int a;
	printf("enter any value");
	scanf("%d", &a);
	switch(a)
	{
		case 1:
			printf("fuihuig");
			break;
			case 2:
				printf("gugugk");
				break;
				case 3:
					printf("hjgkuhg");
					break;
					default:
						printf("cdhgjh");
						break;
	}
}
