#include<iostream>
using namespace std;
int main()
{
	int i,n;
	unsigned long long at=1;
	cout<<"enter any value:";
	cin>>n;
	if(n<0)
	{
		cout<<"error!....";
	}
	else
	{
		for(i=1;i<=n;i++){
			at *=i;
		}
		cout<<n<<"= "<<at;
	}
}
