#include <stdio.h>
int main()
{
	int a=800,b=100;
	(a>b)?printf("a is big"):printf("b is small");
}
