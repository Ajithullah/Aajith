#include<iostream>
using namespace std;
int main()
{

	int a=10;
	while(a<15);
	{
		cout<<"a";
		a++;
	}
}
