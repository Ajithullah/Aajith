#include <stdio.h>
int main()
{
	int x=89,y=98;
	printf ("%d", (x<y));
}
