#include<iostream>
using namespace std;
int main()
{
	char ch[10]={'h','i'};
	{
		cout<<strlen(ch);
	}
}
