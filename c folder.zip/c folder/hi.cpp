#include<iostream>
using namespace std;
int main()
{
	int a,b;
	cout<<"enter any value";
	cin>>a>>b;
	if(a<b)
	{
	if(a=b)
	{
		if(a>b)
		{
			cout<<"hi";
		}
		cout<<"hellow";
		}	
		cout<<"hii";
	}
}
		

