#include<stdio.h>
int main()
{
	FILE *fp;
	fp=fopen("aajith.txt", "r");
	char my[20];
	fgets(my,20,fp);
	printf("%s", my);
	fclose(fp);
}
