#include<stdio.h>
int main()
{
	int a;
	printf("enter any value");
	scanf("%d", &a);
	switch(a)
	{
		case 1:
		printf("monday");
		break;
			case 2:
			printf("tusday");
			break;
		case 3:
			printf("wenesday");
			break;
						case 4:
							printf("thrusday");
							break;
								case 5:
									printf("friday");
									break;
									case 6:
										printf("saturday");
										break;
										default:
										ptintf("sunday");
										break; 
	}
}
