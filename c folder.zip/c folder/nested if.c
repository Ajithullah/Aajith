#include<stdio.h>
int main()
{
	int a,b,c;
	print("enter any value");
	scanf("%d%d", &a,&b);
	c=a+b;
	printf("%d",c);
	c=a*b;
	printf("%d",c);
}
