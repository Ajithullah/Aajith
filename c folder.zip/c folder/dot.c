#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value");
	scanf("%d%d", &a,&b);
	if(a,b)
	{
		if(a<b)
		{
			if(a!=b)
			{
				printf("ugoiuoi");
			}
			printf("jgjihoihu");
		}
		printf("ouoiu");
				}
			}
