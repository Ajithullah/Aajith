#include<stdio.h>
char main()
{
	char aajith[10];
	printf("enter a string");
	gets(aajith);
	printf("%s", strrev(aajith));
}
