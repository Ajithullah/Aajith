#include<iostream>
using namespace std;
class one
{
	public:
		int num1;
		int num2;
		void display()
		{
			num1=20;
		}
		void display()
		{
			num2=30;
		}
		int get value()
		{
			return num1;
		}
		int get value2()
		{
			return num2;
		}
};
int main()
{
	one a;
	a.display();
    cout<<a.get value();
    a.display2();
    cout<<a.get value2();

