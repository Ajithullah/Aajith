#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value");
	scanf("%d%d", &a,&b);
	do{
		printf("%d\n", a);
		a++;
	}
	while(a<=b);
}
