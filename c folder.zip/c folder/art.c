#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value");
	scanf("%d%d", &a,&b);
	switch(a,b)
	{
		case 1:
			printf("frjgt");
			break;
			case 2:
				printf("hfdjg");
				break;
				case 3:
				printf("rdjugu");
				break;
				case 4:
					printf("hgfkjgh");
					break;
					case 5:
						printf("hgfjhghgc");
						break;
						default:
							printf("jgkih");
							break;
	}
}
