#include<stdio.h>
char main()
{
	FILE *fp;
	fp=fopen("aajithullah.text", "r");
	char m[20];
	fgets(m,20,fp);
	printf("%s", m);
	fclose(fp);
}
