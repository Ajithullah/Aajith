#include <stdio.h>
int main()
{
	int x=5,y=1;
	printf ("%d", x+y);
}
