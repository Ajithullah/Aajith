#include<stdio.h>
int main()
{
	int a,b;
	printf("enter any value");
	scanf("%d", &a);
	printf("enter any value");
	scanf("%d", &b);
	do{
		printf("%d\n", a);
		a++;
	}
	while(a<=b);
}
