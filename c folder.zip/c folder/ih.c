#include<stdio.h>
void add();
void sub();
int main()
{
	add ();
	sub ();
}
void add()
{
	int a,b;
	printf("enter a&b value");
	scanf("%d%d", &a,&b);
	printf("%d", a+b);
	return a+b;
	}
	void sub()
	{
		int a,b;
		printf("enter a&b value");
		scanf("%d%d", &a,&b);
		printf("%d", a-b);
		return a-b;
	}
