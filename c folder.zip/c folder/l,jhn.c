#include<stdio.h>
int main()
{
	int a=10;
	printf("%d", ++a);
	{
		int a=90;
		{
			printf("%d", a);
		}
	}
	prinf("%d", a);
}
