<?php include('inc/header.php');  ?>

<?php include('inc/nav.php');  ?>
 
 
 
<div class="container">

    <div class="row text-white">
        <div class="col-md-6 ">
            <img src="images/1.jpeg" alt="" class='img-fluid' style='height:500px;width:500px;'>
        </div>
        <div class="col-md-6 pt-5">
        <h3><b>Multicolor Tshirt</b></h3>
        <h2>Rs 300</h2>
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Unde cumque alias minima tempore qui iusto enim debitis necessitatibus dolores esse quam eaque hic quod, perspiciatis expedita dicta cum veniam in cupiditate? Qui ipsum quos ipsa vel vero exercitationem consequatur quas in praesentium. Quae ipsum commodi laudantium cum nesciunt illum assumenda?</p>            
       
<div class="row">
    <div class="col-md-2">
        Quantity:
    </div>
    <div class="col-md-2">
        <input type="text" class='form-control'>
    </div>
   
</div>
<div class="row ">
    <div class="col-md-12 category">
        Categories - <a href="#">Category 1</a>, <a href="#">Category 2</a>, <a href="#">Category 3</a>
    </div>
    <div class="col-md-12 category">
        Tags - <a href="#">Tag 1</a>, <a href="#">Tag 2</a>, <a href="#">Tag 3</a>
    </div>
</div>
<div class="row mt-4">
    <div class="col-md-4">
        <button class='btn'>Add to Cart</button>
    </div>
</div>


</div>
        
        </div>
</div>





<?php include('inc/footer.php');  ?>



