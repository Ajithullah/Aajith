<?php include('inc/header.php');  ?>

<?php include('inc/nav.php');  ?>
 
 


<div class="content mt-5">
            <ul class="rig columns-4">
                <li>
                    <a href="#"><img class="product-image" src="images/1.jpeg"></a>
                    <h4>Image Title</h4>
                     
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                    <div class="price"> $999.99</div>
                    
                    <hr>
                    <button class="btn btn-default btn-xs pull-right" type="button">
                        <i class="fa fa-cart-arrow-down"></i> Add To Cart
                    </button>
                    <button class="btn btn-default btn-xs pull-left" type="button">
                        <i class="fa fa-eye"></i> Details
                    </button>
                </li>
                <li>
                <a href="#"><img class="product-image" src="images/2.jpeg"></a>
                    <h4>Image Title</h4>
                    
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                    <div class="price"> $999.99</div>
                    
                    <hr>
                    <button class="btn btn-default btn-xs pull-right" type="button">
                        <i class="fa fa-cart-arrow-down"></i> Add To Cart
                    </button>
                    <button class="btn btn-default btn-xs pull-left" type="button">
                        <i class="fa fa-eye"></i> Details
                    </button>
                </li>
                <li>
                <a href="#"><img class="product-image" src="images/3.jpeg"></a>
                    <h4>Image Title</h4>
                    
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                    <div class="price"> $999.99</div>
                    
                    <hr>
                    <button class="btn btn-default btn-xs pull-right" type="button">
                        <i class="fa fa-cart-arrow-down"></i> Add To Cart
                    </button>
                    <button class="btn btn-default btn-xs pull-left" type="button">
                        <i class="fa fa-eye"></i> Details
                    </button>
                </li>
                <li>
                <a href="#"><img class="product-image" src="images/4.jpeg"></a>
                    <h4>Image Title</h4>
                    
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
                    <div class="price"> $999.99</div>
                    
                    <hr>
                    <button class="btn btn-default btn-xs pull-right" type="button">
                        <i class="fa fa-cart-arrow-down"></i> Add To Cart
                    </button>
                    <button class="btn btn-default btn-xs pull-left" type="button">
                        <i class="fa fa-eye"></i> Details
                    </button>
                </li>
             
            </ul>
        </div>










        <?php include('inc/footer.php');  ?>


